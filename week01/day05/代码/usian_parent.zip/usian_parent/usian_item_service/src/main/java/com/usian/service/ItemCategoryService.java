package com.usian.service;

import com.usian.pojo.TbItemCat;
import com.usian.utils.CatResult;

import java.util.List;

public interface ItemCategoryService {

    List<TbItemCat> selectItemCategoryByParentId(Long parentId);

    CatResult selectItemCategoryAll();
}
